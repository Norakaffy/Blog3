Let loader-wrapper = document.querySelector('loader-wrapper');

window.addEventListener('load', function()
{
    loader-wrapper.style.display= 'none';
});